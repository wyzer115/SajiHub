<?php $__env->startSection('title', 'Manajemen Meja'); ?>
<?php $__env->startSection('page-title', 'Meja & QR Code'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Form Tambah Meja -->
    <div class="bg-dark-800 border border-dark-700 rounded-2xl p-6 animate-fade-in-up">
        <form action="<?php echo e(route('admin.tables.store')); ?>" method="POST" class="flex flex-col sm:flex-row gap-4 items-end max-w-2xl">
            <?php echo csrf_field(); ?>
            <div class="flex-1 w-full">
                <label for="table_number" class="block text-dark-300 text-sm font-medium mb-2">Tambah Meja Baru</label>
                <input type="text" name="table_number" id="table_number" required placeholder="Nomor meja baru (contoh: 01, VIP-1)..."
                    class="w-full bg-dark-900 border border-dark-600 text-white rounded-xl px-4 py-3 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 focus:outline-none transition-all">
            </div>
            <button type="submit" class="w-full sm:w-auto bg-brand-500 hover:bg-brand-600 text-white font-semibold px-6 py-3 rounded-xl transition-all hover:shadow-lg hover:shadow-brand-500/25 whitespace-nowrap">
                + Tambah Meja
            </button>
        </form>
        <?php $__errorArgs = ['table_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-400 text-sm mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Grid Meja -->
    <div class="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 gap-4 animate-fade-in-up" style="animation-delay: 100ms;">
        <?php $__empty_1 = true; $__currentLoopData = $tables ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-dark-900 border <?php echo e($table->status == 'empty' ? 'border-green-500/30' : 'border-red-500/30'); ?> rounded-2xl p-5 flex flex-col relative overflow-hidden group">
            
            <div class="absolute top-0 right-0 p-3">
                <?php if($table->status == 'empty'): ?>
                    <span class="inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-400">Kosong</span>
                <?php else: ?>
                    <span class="inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider bg-red-500/10 text-red-400">Terisi</span>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <p class="text-dark-400 text-xs font-medium uppercase tracking-wider mb-1">Meja</p>
                <h3 class="text-3xl font-bold text-white"><?php echo e($table->table_number); ?></h3>
            </div>

            <!-- QR Code Visual -->
            <div class="mb-4 flex flex-col items-center justify-center p-3 bg-dark-800 rounded-xl border border-dark-700/50">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo e(urlencode(route('order.qr', ['branch_id' => $table->branch_id, 'table' => $table->table_number]))); ?>" class="w-24 h-24 bg-white p-1 rounded-lg shadow-inner mb-2 animate-fade-in" alt="QR Meja <?php echo e($table->table_number); ?>">
                <a href="https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=<?php echo e(urlencode(route('order.qr', ['branch_id' => $table->branch_id, 'table' => $table->table_number]))); ?>" target="_blank" class="text-[10px] text-brand-400 hover:text-brand-300 font-bold uppercase tracking-wider flex items-center gap-1">
                    🔍 Cetak / Buka QR
                </a>
            </div>

            <div class="bg-dark-800 rounded-xl p-3 mb-4 border border-dark-700/50 flex-1">
                <p class="text-dark-400 text-[10px] uppercase mb-1">QR Token</p>
                <div class="flex items-center justify-between">
                    <code class="text-dark-200 text-xs font-mono truncate mr-2"><?php echo e(Str::limit($table->qr_code_token, 15)); ?></code>
                    <form action="<?php echo e(route('admin.tables.regenerate-qr', $table)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" title="Regenerate QR" class="text-brand-400 hover:text-brand-300 p-1 bg-brand-500/10 rounded transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                        </button>
                    </form>
                </div>
            </div>

            <div class="flex space-x-2 mt-auto">
                <form action="<?php echo e(route('admin.tables.update', $table)); ?>" method="POST" class="flex-1">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="status" value="<?php echo e($table->status == 'empty' ? 'occupied' : 'empty'); ?>">
                    <button type="submit" class="w-full <?php echo e($table->status == 'empty' ? 'bg-brand-500/10 text-brand-400 hover:bg-brand-500/20' : 'bg-green-500/10 text-green-400 hover:bg-green-500/20'); ?> px-3 py-2 rounded-xl transition-all text-xs font-bold uppercase tracking-wider">
                        <?php echo e($table->status == 'empty' ? 'Set Terisi' : 'Set Kosong'); ?>

                    </button>
                </form>

                <form action="<?php echo e(route('admin.tables.destroy', $table)); ?>" method="POST" onsubmit="return confirm('Hapus meja ini?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-500/10 text-red-400 hover:bg-red-500/20 px-3 py-2 rounded-xl transition-all flex items-center justify-center">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full py-12 text-center bg-dark-900 border border-dark-700 rounded-2xl">
            <svg class="w-16 h-16 text-dark-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
            <p class="text-dark-300 mb-2">Belum ada meja yang terdaftar</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\mlstore2\SajiHub\resources\views/admin/tables/index.blade.php ENDPATH**/ ?>