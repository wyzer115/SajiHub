<?php

namespace App\Http\Controllers\AdminCabang;

use App\Http\Controllers\Controller;
use App\Models\Table;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class TableController extends Controller
{
    public function index()
    {
        $tables = Table::where('branch_id', auth()->user()->branch_id)
            ->withCount(['orders' => function($q) {
                $q->whereIn('order_status', ['pending', 'cooking', 'served']);
            }])->get();
            
        return view('admin.tables.index', compact('tables'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'table_number' => 'required|string|max:50',
            'capacity' => 'nullable|integer|min:1|max:100',
        ]);

        $validated['branch_id'] = auth()->user()->branch_id;
        $validated['capacity'] = $validated['capacity'] ?? 4;
        $validated['qr_code_token'] = Str::random(32);
        
        Table::create($validated);

        return redirect()->back()->with('success', 'Meja berhasil dibuat dengan kapasitas ' . $validated['capacity'] . ' kursi.');
    }

    public function update(Request $request, Table $table)
    {
        if ($table->branch_id !== auth()->user()->branch_id) {
            abort(403);
        }

        $validated = $request->validate([
            'table_number' => 'sometimes|required|string|max:50',
            'capacity' => 'sometimes|required|integer|min:1|max:100',
            'status' => 'sometimes|required|in:empty,occupied',
        ]);

        $table->update($validated);

        if (isset($validated['status']) && $validated['status'] === 'empty') {
            \App\Models\Order::where('table_id', $table->id)
                ->whereIn('order_status', ['pending', 'cooking', 'served'])
                ->update(['order_status' => 'completed']);
        }

        return redirect()->back()->with('success', 'Data meja ' . $table->table_number . ' berhasil diperbarui.');
    }

    public function destroy(Table $table)
    {
        if ($table->branch_id !== auth()->user()->branch_id) {
            abort(403);
        }

        $table->delete();

        return redirect()->back()->with('success', 'Meja berhasil dihapus.');
    }

    public function regenerateQr(Table $table)
    {
        if ($table->branch_id !== auth()->user()->branch_id) {
            abort(403);
        }

        $table->update(['qr_code_token' => Str::random(32)]);

        return redirect()->back()->with('success', 'Token QR Code berhasil dibuat ulang.');
    }

    public function showQr(Table $table)
    {
        if ($table->branch_id !== auth()->user()->branch_id) {
            abort(403);
        }

        $orderUrl = url('/order') . '?branch_id=' . $table->branch_id . '&table=' . $table->qr_code_token;
        // Use Google Charts API for QR generation (no extra package needed)
        $qrImageUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($orderUrl);

        return view('admin.tables.qr', compact('table', 'orderUrl', 'qrImageUrl'));
    }
}
