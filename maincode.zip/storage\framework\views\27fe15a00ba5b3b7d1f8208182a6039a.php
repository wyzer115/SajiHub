<?php
    $manifestPath = public_path('build/manifest.json');
    $isHot = file_exists(public_path('hot'));
    $host = request()->getHost();
    $isLocal = in_array($host, ['localhost', '127.0.0.1', '::1']) || str_ends_with($host, '.test') || str_ends_with($host, '.local');

    // Check potential alternative manifest locations (e.g. shared hosting public_html)
    if (!file_exists($manifestPath)) {
        $possiblePaths = [
            base_path('public_html/build/manifest.json'),
            dirname(base_path()) . '/public_html/build/manifest.json',
            base_path('public/build/manifest.json'),
        ];
        foreach ($possiblePaths as $path) {
            if (file_exists($path)) {
                $manifestPath = $path;
                break;
            }
        }
    }

    $hasManifest = file_exists($manifestPath);
    $manifestData = null;
    if ($hasManifest) {
        $manifestData = json_decode(@file_get_contents($manifestPath), true);
    }
?>

<?php if($isHot && $isLocal): ?>
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php elseif($hasManifest && isset($manifestData['resources/css/app.css']['file'])): ?>
    
    <?php
        $cssFile = $manifestData['resources/css/app.css']['file'];
        $jsFile = $manifestData['resources/js/app.js']['file'] ?? null;
        $fontCss = $manifestData['_fonts-C9MNnjVw.css']['file'] ?? null;
    ?>
    <?php if($fontCss): ?>
        <link rel="stylesheet" href="<?php echo e(asset('build/' . $fontCss)); ?>">
    <?php endif; ?>
    <link rel="preload" as="style" href="<?php echo e(asset('build/' . $cssFile)); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('build/' . $cssFile)); ?>">
    <?php if($jsFile): ?>
        <link rel="modulepreload" href="<?php echo e(asset('build/' . $jsFile)); ?>">
        <script type="module" src="<?php echo e(asset('build/' . $jsFile)); ?>"></script>
    <?php endif; ?>
<?php else: ?>
    
    <?php
        $buildDir = is_dir(public_path('build/assets')) 
            ? public_path('build/assets') 
            : (is_dir(base_path('public_html/build/assets')) ? base_path('public_html/build/assets') : null);
        $cssFiles = $buildDir ? glob($buildDir . '/app-*.css') : [];
        $jsFiles = $buildDir ? glob($buildDir . '/app-*.js') : [];
        $foundCss = !empty($cssFiles) ? basename($cssFiles[0]) : null;
        $foundJs = !empty($jsFiles) ? basename($jsFiles[0]) : null;
    ?>

    <?php if($foundCss): ?>
        <link rel="stylesheet" href="<?php echo e(asset('build/assets/' . $foundCss)); ?>">
        <?php if($foundJs): ?>
            <script type="module" src="<?php echo e(asset('build/assets/' . $foundJs)); ?>"></script>
        <?php endif; ?>
    <?php else: ?>
        
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            brand: {
                                50: '#fff5f5', 100: '#fed7d7', 200: '#feb2b2', 300: '#fc8181',
                                400: '#fa1e0e', 500: '#bd2000', 600: '#8c0000', 700: '#700000',
                                800: '#540000', 900: '#380000'
                            },
                            saji: { maroon: '#8c0000', rust: '#bd2000', red: '#fa1e0e', yellow: '#ffbe0f' },
                            dark: {
                                50: '#f8fafc', 100: '#f1f5f9', 200: '#e2e8f0', 300: '#cbd5e1',
                                400: '#94a3b8', 500: '#64748b', 600: '#475569', 700: '#334155',
                                800: '#1e293b', 900: '#0f172a', 950: '#020617'
                            }
                        }
                    }
                }
            }
        </script>
        <style>
            .sidebar-transition { transition: width 0.3s ease, transform 0.3s ease; }
            .animate-fade-in-up { animation: fadeInUp 0.5s ease-out forwards; }
            @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
            .glass { background: rgba(30, 41, 59, 0.8); backdrop-filter: blur(12px); border: 1px solid rgba(71, 85, 105, 0.3); }
        </style>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\mlstore2\SajiHub\resources\views/partials/head-assets.blade.php ENDPATH**/ ?>